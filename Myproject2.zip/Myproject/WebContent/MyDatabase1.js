var app = angular.module("myApp1", []);

app.controller("myCtrl1", function($scope, $http) {
	
    $http.get("http://localhost:8081/Myproject/all/tests")
    .then(function(response) {
        $scope.myWelcome = response.data;
      
    });
    
   
});