var app = angular.module("myApp", []);

app.controller("myCtrl", function($scope, $http) {
	
    $http.get("http://localhost:8081/Myproject/all/train")
    .then(function(response) {
        $scope.myWelcome = response.data;
      
    });
    
   
});

