var myapp=angular.module("Myproj",[]);
myapp.controller("admin",function($scope)
{
$scope.title="Welcome Admin";
$scope.username="Username";
$scope.password="Password";
});
myapp.controller("firstpage",function($scope)
{
$scope.name="CIT";
$scope.full="Crack In The Track";
$scope.admin="ADMIN";
$scope.user="USER";
});