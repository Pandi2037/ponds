package jdbcTest;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;

import org.springframework.jdbc.core.RowMapper;



public class TestRowMapper implements RowMapper<Test> {

	public Test mapRow(ResultSet rs, int rownum) throws SQLException {
		// TODO Auto-generated method stub
		
		Test testObj =new Test();
		testObj.setTrainId(rs.getInt(1));
		testObj.setTrainName(rs.getString(2));
		testObj.setTrackId(rs.getInt(3));
		testObj.setDriverId(rs.getInt(4));
		testObj.setStatusoftrain(rs.getString(5));
		testObj.setArrival(rs.getString(6));
		testObj.setDeparture(rs.getString(7));
		testObj.setTdate(rs.getString(8));
		//testObj.setTestDuration(rs.getString(3));
		//testObj.setTestCreatedTs(DateFormatter.getNexenFormatDate(rs.getTimestamp(5)));
		//System.out.println("&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&" +rs.getTimestamp(5));
		//System.out.println("&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&" + DateFormatter.getNexenFormatDate(rs.getTimestamp(5)));
		//testObj.setTestChargeBack(rs.getString(6));
		return testObj;
	}

}
