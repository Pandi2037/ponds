package jdbcTest;

import java.sql.Types;
import java.util.Date;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Component;



@Component
public  class TestDaoImpl1 extends JdbcDaoSupport implements ITestDao {

	@Autowired
	public TestDaoImpl1(DataSource datasource) {
		// TODO Auto-generated constructor stub
		setDataSource(datasource);
	}

	public List<Test> getAllTests() throws Exception {
		// TODO Auto-generated method stub
		List<Test> testList = null;

		testList = getJdbcTemplate().query("select * from T_XBBNHCF_CIT1",
				new Object[] {}, new TestRowMapper());

		return testList;
	}

	
	
}
