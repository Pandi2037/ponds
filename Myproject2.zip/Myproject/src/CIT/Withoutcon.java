package CIT;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import org.apache.log4j.Logger;

public class Withoutcon {
	final static Logger logger1 = Logger.getLogger(Withoutcon.class);
	public static Connection demo(){
		Connection con=null;
		try {
			/*Class.forName("oracle.jdbc.driver.OracleDriver");
		con=DriverManager.getConnection("jdbc:oracle:thin:@10.232.71.29:1521:INATP02","shobana","shobana");
		*/
			 Class.forName("org.apache.derby.jdbc.ClientDriver");
			    
			   
			    //create connection object
			    
			  con=DriverManager.getConnection("jdbc:derby://172.24.21.41:1527/mydb","tuser","123");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
		logger1.error("Cannot Access Your Class File");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			logger1.error("Cannot Access Your DataBase");
		}
		
		return(con);
	}

}
