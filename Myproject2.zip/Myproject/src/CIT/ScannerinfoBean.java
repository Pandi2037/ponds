package CIT;

import java.util.Scanner;

public class ScannerinfoBean {
	String name,trainame;
	int phoneno;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getTrainame() {
		return trainame;
	}
	public void setTrainame(String trainame) {
		this.trainame = trainame;
	}
	public int getPhoneno() {
		return phoneno;
	}
	public void setPhoneno(int phoneno) {
		this.phoneno = phoneno;
	}
	
}
