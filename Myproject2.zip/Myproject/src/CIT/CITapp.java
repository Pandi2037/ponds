package CIT;

import java.text.ParseException;
import java.util.Iterator;
import java.util.List;

public class CITapp {

	public static void main(String[] args) throws ParseException {
		System.out.println("welcome to our CIT controller");
		//ValidationDao.evaluation();
		ValidationDao vd=new ValidationDao();
		vd.evaluation();
		
	}

}
