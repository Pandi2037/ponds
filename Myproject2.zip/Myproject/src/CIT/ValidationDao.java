package CIT;
//package FindingCrack;
import java.sql.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.Date;

import org.apache.log4j.Logger;

import Crack.CrackDao;
import Driver.DriverDao;
import TrackSolver.TrackSolverDao;
import Train.TrainDao;
import User.DetailsDao;


public class ValidationDao {
	final static Logger logger1 = Logger.getLogger(ValidationDao.class);
	public static void evaluation() throws ParseException {
	Scanner in=new Scanner(System.in);
	try {
		
		int h=0;
		do
		{
		System.out.println("1.insert Driver data base\n2.insert Train database\n3.Finding Crack\n4.Track solver\n5.Train and Driver Details\n6.exit");
		 h=in.nextInt();
		switch(h)
		{
		case 1:
			DriverDao dd=new DriverDao();
			dd.DriverInsert();
			break;
		case 2:
			TrainDao td=new TrainDao();
			td.TrainInsert();
			break;
		case 3:
			CrackDao cd=new CrackDao();
			cd.trackid();
		
		break;
		case 4:
			TrackSolverDao tsd=new TrackSolverDao();
			//tsd.TrackSolve();
			
					break;
		case 5:
			DetailsDao dd1=new DetailsDao();
			dd1.display();
			break;
		case 6:
			System.exit(0);
		default:
			System.out.println("invalid choice");
			System.exit(0);
		}
		
		}while(h<6);
		
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		logger1.error(e);
	}
	
	}

}
