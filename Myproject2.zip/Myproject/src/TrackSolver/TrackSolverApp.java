package TrackSolver;

import java.sql.SQLException;

public class TrackSolverApp {
public static void main(String args[]) throws SQLException
{
	TrackSolverDao tsd=new TrackSolverDao();
	tsd.display();
}
}
