package TrackSolver;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

import CIT.ScannerinfoBean;
import CIT.Withoutcon;

public class TrackSolverDetails {
	Connection con=null;
	SimpleDateFormat sdf = new SimpleDateFormat("HH:mm");
	List error1=null;
	Scanner in=new Scanner(System.in);
	ResultSet rs=null,rs1=null,rs2=null,rs3=null;
	Statement st=null;
	int p=0,m=0;
public void TrackSolve() throws SQLException, ParseException
{
	con=Withoutcon.demo();
	st=con.createStatement();
	String sql4="select * from T_XBBNHCF_CIT1";
	rs=st.executeQuery(sql4);
	
	
Calendar cal1 = Calendar.getInstance();
    
    int j2=Integer.parseInt(new SimpleDateFormat("HH").format(cal1.getTime()));
	int k1=0,k3=0;
	//int hh2=0,hh3=0;
	//System.out.println("the Train table is");
	
	while(rs.next())
	{
		int hh2=0,hh3=0;
		int a=rs.getInt("trainid");
		String b=rs.getString("trainname");
		int c=rs.getInt("trackid");
		int d=rs.getInt("driverid");
		String o=rs.getString("statusoftrain");
		String h1=rs.getString("arrival");
		String h2=rs.getString("departure");
		if(!h1.equals("bending")&&!h2.equals("bending"))
		{
		Date d1=sdf.parse(h1);
		hh2=Integer.parseInt(new SimpleDateFormat("HH").format(d1));
		
		
		Date d2=sdf.parse(h2);
		hh3=Integer.parseInt(new SimpleDateFormat("HH").format(d2));
		}
		//System.out.print(m+""+c+""+o);
		
		if(hh2==0&hh3==0)
		{
				k3++;
			String sql2="select * from T_XBBNHCF_CIT2";
			rs1=st.executeQuery(sql2);
			
			
			//System.out.println("The Driver Table is ");
			//System.out.println(e);
			while(rs1.next())
			{
				int f=rs1.getInt("driverid");
				String g=rs1.getString("drivername");
				int phoneno=rs1.getInt("driverphone");
				//System.out.print(f+" "+g+" "+phoneno);
				if(d==f)
				{
					if(o.equals("Stopped"))
							{
								
						error1=new ArrayList<ScannerinfoBean>();	
					
						k1++;
						System.out.println("Enter the arrival and departure time");
						String g2=in.next();
						String g3=in.next();
					String sq13="update T_XBBNHCF_CIT1 set statusoftrain='Running',arrival='"+g2+"',departure='"+g3+"' where driverid="+f;
					String sq14="insert into T_XBBNHCF_Solved values('"+a+"','"+b+"','"+g+"')";
					System.out.println("The track problem is solved  call the Train Driver to run a train:  "+g+"  :    "+phoneno);
					System.out.println("The train name is :    "+b+"    :Running Now");
					rs2=st.executeQuery(sq13);
					rs3=st.executeQuery(sq14);
					//	error.add(g+""+phoneno+""+b);
					ScannerinfoBean sib=new ScannerinfoBean();
					sib.setName(g);
					sib.setPhoneno(phoneno);
					sib.setTrainame(b);
					error1.add(sib);
					//return(error1);
					
					}
				}
				
				//System.out.println("");
			
		}
			
		}
		//System.out.println("");
	}
	if(k1==0&&k3==0)
		System.out.println("No track like this");
	else if(k1==0)
		System.out.println("The train is already running");
	try
	{
con.close();
st.close();
rs.close();
rs1.close();
rs2.close();
rs3.close();
	}
	catch(Exception e)
	{
		
	}
}

}
