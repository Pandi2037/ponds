package Driver;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import org.apache.log4j.Logger;

import CIT.Withoutcon;

public class DriverDao {
	final static Logger logger1 = Logger.getLogger(DriverDao.class);
public void DriverInsert()
{
	Scanner d=new Scanner(System.in);
	logger1.info("enter no of rows to be added");
	int a=d.nextInt();
	Connection con=null;
Statement st=null;
ResultSet rs=null;
		
		try {
			con=Withoutcon.demo();
			 st=con.createStatement();
			for(int i=0;i<a;i++)
			{
				logger1.info("enter driverid drivername phoneno");
				int b=d.nextInt();
				String name=d.next();
				int c=d.nextInt();
				String sql="insert into T_XBBNHCF_CIT2 values('"+b+"','"+name+"','"+c+"')";
				rs=st.executeQuery(sql);
				//rs.close();
			}
			//st.close();
			//con.close();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			logger1.error(e);
		}
		finally
		{
			try {
				con.close();
				st.close();
				rs.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				logger1.error(e);
			}
		}
		



}
public void dislpay()
{
	Connection con1=null;
	Statement st2=null;
	ResultSet rs2=null;
	
	try {
		con1=Withoutcon.demo();
		//st1=con1.createStatement();
		st2=con1.createStatement();
		//String sql1="select * from T_XBBNHCF_CIT1";
		String sql2="select * from T_XBBNHCF_CIT2";
		//rs1=st1.executeQuery(sql1);
		rs2=st2.executeQuery(sql2);
		logger1.info("Driver details and Driver details are");
		System.out.printf("%-20s%-20s%-20s\n","DriverId","DriverName","DriverPhoneNumber");
		while(rs2.next())
		{
			
			//System.out.println("hello");
			System.out.printf("%-20d%-20s%-20d\n",rs2.getInt("driverid"),rs2.getString("drivername"),rs2.getInt("driverphone"));
			
		}
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		logger1.error(e);
	}
	finally
	{
		try {
			con1.close();
			//st1.close();
			st2.close();
			//rs1.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			logger1.error(e);
		}
		
	}
}


}
