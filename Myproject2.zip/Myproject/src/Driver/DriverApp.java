package Driver;

public class DriverApp {
public static void main(String args[])
{
	DriverDao da=new DriverDao();
	da.dislpay();
}
}
