package Train;

import java.text.ParseException;

public class TrainApp {
public static void main(String args[]) throws ParseException
{
	TrainDao td=new TrainDao();
	td.TrainDisplay();
}
}
