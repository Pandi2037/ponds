package Train;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.util.Scanner;

import CIT.Withoutcon;

import java.util.*;

import org.apache.log4j.Logger;
public class TrainDao {
	final static Logger logger1 = Logger.getLogger(TrainDao.class);
public void TrainInsert()
{
	Scanner d=new Scanner(System.in);
	logger1.info("enter no of rows to be added");
	int a=d.nextInt();
	Connection con=null;
	Statement st=null;
	ResultSet rs=null;
		
		try {
			con=Withoutcon.demo();
			st=con.createStatement();
			for(int i=0;i<a;i++)
			{
				logger1.error("enter trainid trainname trackid driverid trainstatus arrival departure");
				int b=d.nextInt();
				String name=d.next();
				int c=d.nextInt();
				int e=d.nextInt();
				d.nextLine();
				String s=d.next();
				String s1=d.next();
				String sql="insert into T_XBBNHCF_CIT1 values('"+b+"','"+name+"','"+c+"','"+e+"','Running','"+s+"','"+s1+"')";
				rs=st.executeQuery(sql);
				logger1.info("The Train Details are inserted SuccessFully");
			//	rs.close();
			}
			//st.close();
			//con.close();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			logger1.error(e);
		}
		
		finally
		{
			try {
				con.close();
				st.close();
				rs.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				logger1.error(e);
			}
		}

}
public List TrainDisplay()
{

	Connection con1=null;
	Statement st1=null;
	ResultSet rs1=null;
	List<TrainBean> ls=new ArrayList<TrainBean>();
	try {
		con1=Withoutcon.demo();
		st1=con1.createStatement();
		//st2=con1.createStatement();
		String sql1="select * from T_XBBNHCF_CIT1";
		//String sql2="select * from T_XBBNHCF_CIT2";
		rs1=st1.executeQuery(sql1);
		//rs2=st2.executeQuery(sql2);
		//System.out.println("Train details and Driver details are");
		//System.out.printf("%-20s%-20s%-20s%-20s%-20s%-20s%-20s\n", "TrainId","TrainName","TrackId","DriverId","Status","Arrival","Departure");
		while(rs1.next())
		{
			ls.add(new TrainBean(rs1.getInt("trainid"),rs1.getString("trainname"),rs1.getInt("trackid"),rs1.getString("arrival"),rs1.getString("departure"),rs1.getDate("tdate")));
			
			//System.out.println("hello");
			//System.out.printf("%-20d%-20s%-20d%-20d%-20s%-20s%-20s\n",rs1.getInt("trainid"),rs1.getString("trainname"),rs1.getInt("trackid"),rs1.getInt("driverid"),rs1.getString("statusoftrain"),rs1.getString("arrival"),rs1.getString("departure"));
			
		}
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	finally
	{
		try {
			con1.close();
			st1.close();
			//st2.close();
			rs1.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	return(ls);
}

}
