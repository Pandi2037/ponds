package Train;
import java.util.*;
import java.text.*;
public class TrainBean {
String trainame,arrival,departure;
int trainid,trackid;
Date tdate=new Date(); 

TrainBean(int a,String b,int c,String d,String f,Date g)
{
	this.trainid=a;
	this.trainame=b;
	this.trackid=c;
	this.arrival=d;
	this.departure=f;
	
	this.tdate=g;
	
}
public String getTrainame() {
	return trainame;
}
public void setTrainame(String trainame) {
	this.trainame = trainame;
}
public String getArrival() {
	return arrival;
}
public void setArrival(String arrival) {
	this.arrival = arrival;
}
public String getDeparture() {
	return departure;
}
public void setDeparture(String departure) {
	this.departure = departure;
}
public int getTrainid() {
	return trainid;
}
public void setTrainid(int trainid) {
	this.trainid = trainid;
}
public int getTrackid() {
	return trackid;
}
public void setTrackid(int trackid) {
	this.trackid = trackid;
}
public Date getTdate() {
	return tdate;
}
public void setTdate(Date tdate) {
	this.tdate = tdate;
}

}
