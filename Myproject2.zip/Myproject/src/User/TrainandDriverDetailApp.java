package User;

public class TrainandDriverDetailApp {
	public static void main(String args[])
	{
DetailsDao dd=new DetailsDao();
dd.display();
	}
}
