package User;
import java.util.*;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import CIT.Withoutcon;

public class DetailsDao {
public List display()
{
	Connection con1=null;
	Statement st1=null,st2=null;
	ResultSet rs1=null,rs2=null;
	List<DetailsDaoBean> ls=new ArrayList<DetailsDaoBean>();
	try {
		con1=Withoutcon.demo();
		st1=con1.createStatement();
		st2=con1.createStatement();
		String sql1="select * from T_XBBNHCF_CIT1";
		String sql2="select * from T_XBBNHCF_CIT2";
		rs1=st1.executeQuery(sql1);
		rs2=st2.executeQuery(sql2);
		//System.out.println("Train details and Driver details are");
		//System.out.printf("%-20s%-20s%-20s%-20s%-20s%-20s%-20s%-20s%-20s\n", "TrainId","TrainName","TrackId","DriverId","DriverName","DriverPhoneNumber","Status","Arrival","Departure");
		while(rs1.next()&&rs2.next())
		{
			ls.add(new DetailsDaoBean(rs1.getInt("trainid"),rs1.getString("trainname"),rs1.getInt("trackid"),rs1.getInt("driverid"),rs2.getInt("driverphone"),rs2.getString("drivername"),rs1.getString("arrival"),rs1.getString("departure"),rs1.getString("statusoftrain"),rs1.getDate("tdate")));
			//System.out.println("hello");
			//System.out.printf("%-20d%-20s%-20d%-20d%-20s%-20d%-20s%-20s%-20s\n",rs1.getInt("trainid"),rs1.getString("trainname"),rs1.getInt("trackid"),rs1.getInt("driverid"),rs2.getString("drivername"),rs2.getInt("driverphone"),rs1.getString("statusoftrain"),rs1.getString("arrival"),rs1.getString("departure"));
			
		}
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	finally
	{
		try {
			con1.close();
			st1.close();
			st2.close();
			rs1.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	return(ls);
}

}

