package User;
import java.util.*;
public class DetailsDaoBean {
int trainid,trackid,driverid,driverphoneno;
String trainname,drivername,arrival,departure,status;
Date tdate=new Date();
DetailsDaoBean(int a,String b,int c,int d,int e,String f,String g,String h,String i,Date j)
{
	this.trainid=a;
	this.trainname=b;
	this.trackid=c;
	this.driverid=d;
	this.driverphoneno=e;
	this.drivername=f;
	this.arrival=g;
	this.departure=h;
	this.status=i;
	this.tdate=j;
}
public int getTrainid() {
	return trainid;
}
public int getTrackid() {
	return trackid;
}
public int getDriverid() {
	return driverid;
}
public int getDriverphoneno() {
	return driverphoneno;
}
public String getTrainname() {
	return trainname;
}
public String getDrivername() {
	return drivername;
}
public String getArrival() {
	return arrival;
}
public String getDeparture() {
	return departure;
}
public String getStatus() {
	return status;
}
public Date getTdate() {
	return tdate;
}

}
