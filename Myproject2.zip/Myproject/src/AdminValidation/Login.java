package AdminValidation;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import CIT.Withoutcon;

public class Login {
public int validate(String c,String b)
{
	int a=0;
	Connection con=null;
	Statement stmt=null;
	
	try {
	
		con=Withoutcon.demo();
		 stmt = con.createStatement();
         String sql;
         sql = "select * from T_XBBNHCF_Admin";
         ResultSet rs = stmt.executeQuery(sql);
         while(rs.next())
         {
        	String d=rs.getString("username");
        	String e=rs.getString("password");
        //	System.out.println(c+""+d+""+b+""+e);
        	if(d.equals(c)&&e.equals(b))
        		a=1;
         }
         //System.out.println(a);
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		System.out.println("sql query is wrong");
	}
	return(a);
}

}
