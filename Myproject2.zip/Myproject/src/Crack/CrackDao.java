package Crack;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

import org.apache.log4j.Logger;

import CIT.ScannerinfoBean;
import CIT.Withoutcon;

public class CrackDao {
	final static Logger logger1 = Logger.getLogger(CrackDao.class);
	public static List trackid() throws SQLException, ParseException
	{
		Scanner q=new Scanner(System.in);
		int f1=0;
		List<CrackBean> ls=new ArrayList<CrackBean>();
		Connection con=null;
		SimpleDateFormat sdf = new SimpleDateFormat("HH:mm");
		ResultSet rs=null,rs1=null,rs2=null,rs3=null;
		Statement st=null;
		int p=0,m=0;
		 Calendar cal = Calendar.getInstance();
	     int s=0;   
	      int j1=Integer.parseInt(new SimpleDateFormat("HH").format(cal.getTime()));
		logger1.info("enter wheather track has crack or animal or bad weather");
		do
		{
		logger1.info("1.crack \n2.animal \n3.rainy");
		s=q.nextInt();
	CrackBean cb=new CrackBean();
		if(s==1||s==2||s==3)
		{
			if(s==1)
				cb.setError("crack");
			else if(s==2)
				cb.setError("animal");
			else 
				cb.setError("rainy");
			logger1.info("enter that track id");
			//System.out.println("the Train table is");
			//q.nextLine();
			f1=q.nextInt();
			con=Withoutcon.demo();
			st=con.createStatement();
			//System.out.println("the Train table is");
			String sql="select * from T_XBBNHCF_CIT1";
			//System.out.println("the Train table is");
			rs=st.executeQuery(sql);
			//System.out.println("the Train table is");
			//p=ScannerinfoBean.trackid();
			
		      //  System.out.println(j1);
			//ArrayList error=new ArrayList();
			int k=0,k2=0;
			int hh=0,hh1=0;
			
			//System.out.println("the Train table is");
			
			while(rs.next())
			{
				int a=rs.getInt("trainid");
				String b=rs.getString("trainname");
				int c=rs.getInt("trackid");
				int d=rs.getInt("driverid");
				String h1=rs.getString("arrival");
				if(!h1.equals("bending"))
				{
				Date d1=sdf.parse(h1);
				 hh=Integer.parseInt(new SimpleDateFormat("HH").format(d1));
				}
				String h2=rs.getString("departure");
				if(!h2.equals("bending"))
				{	
				Date d2=sdf.parse(h2);
				hh1=Integer.parseInt(new SimpleDateFormat("HH").format(d2));
				}
				//System.out.println(hh+" "+hh1);
				//System.out.print(a+" "+b+" "+c+" "+d);
			
				if(f1!=0)
				{
					if(f1==c)
					{
					k2++;	
					if(hh<=j1&&j1<=hh1)
					{
					String sql2="select * from T_XBBNHCF_CIT2";
					rs1=st.executeQuery(sql2);
					
					
					//System.out.println("The Driver Table is ");
					//System.out.println(e);
					while(rs1.next())
					{
						int f=rs1.getInt("driverid");
						String g=rs1.getString("drivername");
						int phoneno=rs1.getInt("driverphone");
						//System.out.print(f+" "+g+" "+phoneno);
						if(d==f)
						{k++;
							String sq13="update T_XBBNHCF_CIT1 set statusoftrain='Stopped',arrival='bending',departure='bending' where driverid="+f;
							String sq14="insert into T_XBBNHCF_Error values('"+a+"','"+b+"','"+g+"')";
							logger1.info("There is error in the Track call the Train Driver:   "+g+"  :    "+phoneno);
							logger1.info("The train name is :   "+b+"    :Stopped");
							rs2=st.executeQuery(sq13);
							rs3=st.executeQuery(sq14);
							ls.add(new CrackBean(a,b,c,f,g,phoneno));
							
							//error.add(g+""+phoneno+""+b);
							
							
						}
						//System.out.println("");
					}
				}
					}
				}
				//System.out.println("");
			}
			if(k==0 && k2!=0)
				logger1.info("No train comming this time no need to initmate driver and updating train database");
			else if(k==0)
				logger1.info("No Track Like this");
			//Iterator itrl1=error.iterator();
		/*	while(itrl1.hasNext())
			{
				System.out.println(itrl1.next());
			}*/
			
			cb.setChoice(f1);
			
		}
		else
		{
			logger1.error("choose a valid crack option crack");
		}
		}while(s>3);
		//return(f1);
		try
		{
		con.close();
		st.close();
		rs.close();
		rs1.close();
		rs2.close();
		rs3.close();
		}
		catch(Exception e)
		{
			
		}
		return(ls);
	}
	public static void display() throws SQLException
	{
		Connection con=null;
		ResultSet rs=null;
		Statement st=null;
		con=Withoutcon.demo();
		st=con.createStatement();
		String s="select * from T_XBBNHCF_Error";
		rs=st.executeQuery(s);
		logger1.info("Crack Occured Tracks Are:");
		System.out.printf("%-20s%-20s%-20s\n","TrainId","TrainName","DriverName");
		while(rs.next())
		{
			System.out.printf("%-20d%-20s%-20s\n",rs.getInt("trainid"),rs.getString("trainname"),rs.getString("drivername"));
		}
		try
		{
		rs.close();
		}
		catch(Exception e)
		{
		
		}
	}
	

}
