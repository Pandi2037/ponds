package Crack;

import java.sql.SQLException;

import org.apache.log4j.Logger;

import CIT.Withoutcon;

public class CrackApp {
	final static Logger logger1 = Logger.getLogger(CrackApp.class);
public static void main(String args[]) throws SQLException
{
	CrackDao cd=new CrackDao();
	//System.out.println("Error is"+cb.getError());
	//System.out.println("Track id is"+cb.getChoice());
	cd.display();
}
}
