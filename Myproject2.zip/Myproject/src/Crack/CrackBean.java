package Crack;

public class CrackBean {
private String error,trainname,drivername;
private int choice,id,phoneno,driverid,trackid;
public int getDriverid() {
	return driverid;
}
public void setDriverid(int driverid) {
	this.driverid = driverid;
}
public CrackBean(int a,String b,int g,int c,String d,int f)
{
	this.id=a;
	this.trackid=g;
	this.trainname=b;
	this.driverid=c;
	this.drivername=d;
	this.phoneno=f;
	
}
public int getTrackid() {
	return trackid;
}
public void setTrackid(int trackid) {
	this.trackid = trackid;
}
public String getTrainname() {
	return trainname;
}
public void setTrainname(String trainname) {
	this.trainname = trainname;
}
public String getDrivername() {
	return drivername;
}
public void setDrivername(String drivername) {
	this.drivername = drivername;
}
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public int getPhoneno() {
	return phoneno;
}
public void setPhoneno(int phoneno) {
	this.phoneno = phoneno;
}

CrackBean()
{
	error="";
	choice=0;
}
public String getError() {
	return error;
}
public void setError(String error) {
	this.error = error;
}
public int getChoice() {
	return choice;
}
public void setChoice(int choice) {
	this.choice = choice;
}
}
