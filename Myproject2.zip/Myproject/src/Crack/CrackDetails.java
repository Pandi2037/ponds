package Crack;
import java.util.*;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;

import org.apache.log4j.Logger;

import CIT.Withoutcon;

public class CrackDetails {
	final static Logger logger1 = Logger.getLogger(CrackDetails.class);
	Connection con=null;
	//SimpleDateFormat sdf = new SimpleDateFormat("HH:mm");
	ResultSet rs=null,rs1=null,rs2=null,rs3=null;
	Statement st=null,st1=null;
	int l=0;
	List<CrackBean> ls=new ArrayList<CrackBean>();
	public List display() throws SQLException
	{
		
	con=Withoutcon.demo();
	st=con.createStatement();
	st1=con.createStatement();
	//System.out.println("the Train table is");
	String sql="select * from T_XBBNHCF_CIT1";
	rs=st.executeQuery(sql);
	
	//System.out.println("came");
	while(rs.next())
	{//System.out.println("came");
		int d=rs.getInt("driverid");
		
		String a=rs.getString("statusoftrain");
		String b=rs.getString("arrival");
		String c=rs.getString("departure");
		if(a.equals("Stopped")&&b.equals("bending")&&c.equals("bending"))
		{//System.out.println("came");
			String sql2="select * from T_XBBNHCF_CIT2";
			rs1=st1.executeQuery(sql2);
			
		while(rs1.next())
		{
			int e=rs1.getInt("driverid");
		if(d==e)
		{
			//System.out.println("came");
			ls.add(new CrackBean(rs.getInt("trainid"),rs.getString("trainname"),rs.getInt("trackid"),rs.getInt("driverid"),rs1.getString("drivername"),rs1.getInt("driverphone")));
		}
		}
	//	rs1=st1.executeQuery(sql2);
		}
	}
	return(ls);
	}
}
