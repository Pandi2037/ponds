package t;

public class Hai {
int trackid,width,height;


public Hai(int trackid, int width, int height) {
	super();
	this.trackid = trackid;
	this.width = width;
	this.height = height;
}

public int getTrackid() {
	return trackid;
}

public void setTrackid(int trackid) {
	this.trackid = trackid;
}

public int getWidth() {
	return width;
}

public void setWidth(int width) {
	this.width = width;
}

public int getHeight() {
	return height;
}

public void setHeight(int height) {
	this.height = height;
}
}
