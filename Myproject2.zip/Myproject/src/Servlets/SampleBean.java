package Servlets;


import java.util.Date;

public class SampleBean {
	
	private String param1;
	private Date param2 = new Date();
	private int  param3;
	
	public int getParam3() {
		return param3;
	}
	public void setParam3(int param3) {
		this.param3 = param3;
	}
	public String getParam1() {
		return param1;
	}
	public void setParam1(String param1) {
		this.param1 = param1;
	}
	
	public Date getParam2() {
		return param2;
	}
	public void setParam2(Date param2) {
		this.param2 = param2;
	}
	
	@Override
	public String toString() {
		return "SampleBean [param1=" + param1 + ", param2=" + param2 + "]";
	}

}
