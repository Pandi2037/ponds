package Servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.*;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import CIT.Withoutcon;
import Crack.CrackBean;

/**
 * Servlet implementation class Alert
 */
@WebServlet("/Alert")
public class Alert extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Alert() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
				}
	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		Connection con=null;
		//SimpleDateFormat sdf = new SimpleDateFormat("HH:mm");
		ResultSet rs=null,rs1=null,rs2=null,rs3=null;
		Statement st=null,st1=null;
		int l=0;
		List<CrackBean> ls=new ArrayList<CrackBean>();
		PrintWriter out=response.getWriter();
		//System.out.println("hello");	
		con=Withoutcon.demo();
		try {
			st=con.createStatement();
			st1=con.createStatement();
			//System.out.println("the Train table is");
			String sql="select * from T_XBBNHCF_CIT1";
			rs=st.executeQuery(sql);
			String sql2="select * from T_XBBNHCF_CIT2";
			rs1=st1.executeQuery(sql2);
			//System.out.println("came");
			while(rs.next())
			{//System.out.println("came");
				int d=rs.getInt("driverid");
				
				String a=rs.getString("statusoftrain");
				String b=rs.getString("arrival");
				String c=rs.getString("departure");
				if(a.equals("Stopped")&&b.equals("bending")&&c.equals("bending"))
				{//System.out.println("came");
				while(rs1.next())
				{
					int e=rs1.getInt("driverid");
				if(d==e)
				{
					l++;
					//System.out.println("came");
					//ls.add(new CrackBean(rs.getInt("trainid"),rs.getString("trainname"),rs.getInt("driverid"),rs1.getString("drivername"),rs1.getInt("driverphone")));
				}
				}
				}
			}
			if(l!=0)
			{
				
				
				
				out.println("<html><body><script>alert('THERE IS CRACK IN THE TRACK CLICK ON CRACK BUTTON');</script></body></html>");
			}
			RequestDispatcher rd=request.getRequestDispatcher("try.jsp");
			rd.include(request, response);
			
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		//return(ls);

	}

}
