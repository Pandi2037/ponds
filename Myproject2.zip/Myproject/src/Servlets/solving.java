package Servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Crack.CrackBean;
import Crack.CrackDetails;
import TrackSolver.TrackSolverDao;

/**
 * Servlet implementation class solving
 */
@WebServlet("/solving")
public class solving extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public solving() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		TrackSolverDao tsd=new TrackSolverDao();
		PrintWriter out=response.getWriter();
		int a=Integer.parseInt(request.getParameter("trackid"));
		String b=request.getParameter("stime");
		String c=request.getParameter("dtime");
		response.setContentType("text/html");
		
		List<CrackBean> ls=new ArrayList<CrackBean>();
		Cookie ck[]=request.getCookies();
		int k=0,o=0;
		//out.println("<html><body>Hi</body></html>");
		 if(ck!=null){ 
			// out.println("<html><body>Hi</body></html>");
		for(int i=0;i<ck.length;i++)
		{
		///out.println(ck[i].getName()+""+ck[i].getValue()+""+i);
			//out.println("<html><body>Hi</body></html>");
        
         String name=ck[i].getName();  
        // out.println(name);
        if(name.equals("username")){
        	//out.println("<html><body>Hi</body></html>");
        	k=1;
        }
        }
        }
	if(k==1)
	{
		CrackDetails cd=new CrackDetails();
		try {
			ls=cd.display();
			 
			if(ls!=null)
			{
								
			
				for(CrackBean cb:ls)
				{
					if(cb.getTrackid()==a)
					{
						o=1;
					}
	    
				}
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	
	System.out.println(o);
if(o==1)
{
				
		out.println("<html><body><script>alert('WAIT FOR FEW MINUTES TRACK is GOING TO Solved');</script></body></html>");
		try {
			tsd.TrackSolve(a,b,c);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		out.println("<head><script language='javascript'>window.location.href='try.jsp';</script></head></html>");
}
else
{
	out.println("<html><body><script>alert('Please Fill All The Fields with Correct Details');</script></body></html>");
	out.println("<head><script language='javascript'>window.location.href='GetInfo.html';</script></head></html>");
}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
