package Servlets;
import java.text.*;
import java.text.ParseException;
import java.util.*;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Train.*;

/**
 * Servlet implementation class Display
 */
@WebServlet("/Display")
public class Display extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Display() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		List<TrainBean> ls=new ArrayList<TrainBean>();
		

		PrintWriter out=response.getWriter();
		//out.println("hello");
		DateFormat df=new SimpleDateFormat("yyyy-MM-dd");
		Date d=new Date();
		RequestDispatcher rd=request.getRequestDispatcher("filter.jsp");
		rd.include(request, response); 
			response.setContentType("text/html");
		 String a=request.getParameter("sdate");
			//System.out.println(a);
			//a="22-07-1996";
			String b[]=a.split("-");
			
	TrainDao td=new TrainDao();
	int q=0;
		ls=td.TrainDisplay();
		out.println("<html><head>");
		for(TrainBean tb:ls)
		{
			int k=0;
			if(tb.getTdate()!=null)
			{
			String h=df.format(tb.getTdate());
			//out.println(h);
			String c[]=h.split("-");
			for(int i=0;i<c.length;i++)
			{
				//out.println(b[i]+" "+c[i]);
				if(b[i].equals(c[i]))
				{k++;
					
				}
			}
			}
			if(k==b.length)
			{
				if(q==0)
					out.println("<style>#demo{padding-left:70%;padding-top:10%;}</style></head><center><body><table id='demo'><tr><th>TrainId</th><th>TrainName</th><th>TrackId</th><th>Arrival</th><th>Departure</th><th>Date</th></tr>");
			q++;
			out.println("<tr>");
			out.println("<td>"); out.println(tb.getTrainid()); 	out.println("</td>");
			out.println("<td>");out.println(tb.getTrainame());  	out.println("</td>");
			out.println("<td>");out.println(tb.getTrackid());	out.println("</td>");
			out.println("<td>");out.println(tb.getArrival());	out.println("</td>");
			out.println("<td>");out.println(tb.getDeparture());	out.println("</td>");
			out.println("<td>");out.println(tb.getTdate());	out.println("</td>");
			out.println("</tr>");
			}
		}
		if(q==0)
		{
			out.println("<script>alert('No Train in this time');</script>");
			
			
		}
	out.println("</center></table></body></html>");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
