package Servlets;

import java.io.IOException;
import java.sql.SQLException;
import java.util.*;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Crack.*;

/**
 * Servlet implementation class solver
 */
@WebServlet("/solver")
public class solver extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public solver() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		List<CrackBean> ls=new ArrayList<CrackBean>();
		Cookie ck[]=request.getCookies();
		int k=0,o=0;
		//out.println("<html><body>Hi</body></html>");
		 if(ck!=null){ 
			// out.println("<html><body>Hi</body></html>");
		for(int i=0;i<ck.length;i++)
		{
		///out.println(ck[i].getName()+""+ck[i].getValue()+""+i);
			//out.println("<html><body>Hi</body></html>");
        
         String name=ck[i].getName();  
        // out.println(name);
        if(name.equals("username")){
        	//out.println("<html><body>Hi</body></html>");
        	k=1;
        }
        }
        }
	if(k==1)
	{
		CrackDetails cd=new CrackDetails();
		try {
			ls=cd.display();
			 
			if(ls!=null)
			{
				System.out.println(o);				
			
				for(CrackBean cb:ls)
				{
					o++;
					if(o==1)
					{
						out.println("<html><body><center><form action='GetInfo.html' method='get'><input type='submit' value='CLICK TO UPDATE THE STATUS'></form></center></body></html>");
						out.println("<html><head><style>table, th, td {border: 1px solid black;}</style></head><center><body><table><tr><th>TrainId</th><th>TrainName</th><th>TrackId</th><th>DriverId</th><th>DriverName</th><th>DriverPhoneNumber</th></tr>");	
					}
		        	out.println("<tr>");
	    			out.println("<td>"); out.println(cb.getId()); 	out.println("</td>");
	    			out.println("<td>");out.println(cb.getTrainname());  	out.println("</td>");
	    			out.println("<td>");out.println(cb.getTrackid());  	out.println("</td>");
	    			out.println("<td>");out.println(cb.getDriverid());	out.println("</td>");
	    			out.println("<td>");out.println(cb.getDrivername());	out.println("</td>");
	    			out.println("<td>");out.println(cb.getPhoneno());	out.println("</td>");
	    			out.println("</tr>");
	    
				}
			}
			if(o==0)
			{
				out.print("<html><head><script>alert('No track Has Errors');window.location.href='try.jsp';</script></head></html>");  
		      
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	else
	{
		out.println("<head><script language='javascript'>window.location.href='admin1.html';alert('Please Login First');</script></head></html>");
	}
	
	

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
