package Servlets;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Random;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import AdminValidation.*;
import wiat.*;

/**
 * Servlet implementation class Admin
 */
@WebServlet("/Admin")
public class Admin extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public Admin() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		String a=request.getParameter("usr");
		String b=request.getParameter("pas");
		 
		Login l=new Login();
		int c=l.validate(a, b);
		
		//System.out.println(c);
		//out.println("<html><head><script language='javascript'>");
		if(c==0)
		{System.out.println("from"+c);
			 
			out.println("<html><head><script>alert('Sorry UserName or Password Error!')</script></head></html>");  
	    //   RequestDispatcher rd=request.getRequestDispatcher("admin1.html");
	      // rd.include(request, response);
		}
		else if(c==1)
		{
			
			 Cookie ck=new Cookie("username",a);
			 ck.setMaxAge(32);//creating cookie object  
			    response.addCookie(ck);
			HttpSession session=request.getSession();
			Integer count=(Integer)session.getAttribute(a);
			if(count==null)
				count=new Integer(1);
			else
				count=new Integer(count.intValue()+1);
			session.setAttribute(a, count);
			RequestDispatcher rd1=request.getRequestDispatcher("Alert");
	       rd1.include(request, response);  
			
			
			
			//RequestDispatcher rd=request.getRequestDispatcher("/adminpage.html");
	        //rd.include(request, response);  
	       
		}
		//out.println("</script></head></html>");
	
		
		
		/*response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		String a=request.getParameter("usr");
		String b=request.getParameter("pas");
		//out.println("hi");
	
	int c=Demo1.validate(a, b);
		if(c==0)
			out.println("hello");
		else
			out.println("hi");
	  /* Connection conn=null;
	   Statement stmt=null;
	      try{
	         // Register JDBC driver
	         Class.forName("com.mysql.jdbc.Driver");

	         // Open a connection
	          conn=DriverManager.getConnection("jdbc:oracle:thin:@10.232.71.29:1521:INATP02","shobana","shobana");

	         // Execute SQL query
	         stmt = conn.createStatement();
	         String sql;
	         sql = "select * from T_XBBNHCF_Admin";
	         ResultSet rs = stmt.executeQuery(sql);
	         int k=0;
	         // Extract data from result set
	         while(rs.next()){
	            //Retrieve by column name
	         String c=rs.getString("username");
	         String d=rs.getString("password");
	         if(c.equals(a)&&d.equals(b))
	         {
	        	 k=1;
	        	 break;
	         }
	         }
	         out.println("</body></html>");

	         // Clean-up environment
	         rs.close();
	         stmt.close();
	         conn.close();
	      }catch(SQLException se){
	         //Handle errors for JDBC
	         se.printStackTrace();
	      }catch(Exception e){
	         //Handle errors for Class.forName
	         e.printStackTrace();
	      }finally{
	         //finally block used to close resources
	         try{
	            if(stmt!=null)
	               stmt.close();
	         }catch(SQLException se2){
	         }// nothing we can do
	         try{
	            if(conn!=null)
	            conn.close();
	         }catch(SQLException se){
	            se.printStackTrace();
	         }//end finally try
	      } //end try*/
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		String a=request.getParameter("usr");
		String b=request.getParameter("pas");
		 
		Login l=new Login();
		int c=l.validate(a, b);
		
		//System.out.println(c);
		//out.println("<html><head><script language='javascript'>");
		if(c==0)
		{//System.out.println("from"+c);
			 
		out.println("<html><head><script>alert('Sorry UserName or Password Error!');</script></head></html>");  
	      RequestDispatcher rd=request.getRequestDispatcher("admin1.html");
	       rd.include(request, response);  
		}
		else if(c==1)
		{
			
			 Cookie ck=new Cookie("username",a);
			 ck.setMaxAge(32);//creating cookie object  
			    response.addCookie(ck);
			HttpSession session=request.getSession();
			Integer count=(Integer)session.getAttribute(a);
			if(count==null)
				count=new Integer(1);
			else
				count=new Integer(count.intValue()+1);
			session.setAttribute(a, count);
			RequestDispatcher rd1=request.getRequestDispatcher("Alert");
	       rd1.include(request, response);  
			
			
			
			//RequestDispatcher rd=request.getRequestDispatcher("/adminpage.html");
	        //rd.include(request, response);  
	       
		}
	/*	if(c==0)
		{
			RequestDispatcher rd=request.getRequestDispatcher("admin1.html");
			rd.include(request, response);
		}*/
		//out.println("</script></head></html>");
	}

}
 