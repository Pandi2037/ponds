package Servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.*;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import User.*;

/**
 * Servlet implementation class displaydetails
 */
@WebServlet("/displaydetails")
public class displaydetails extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public displaydetails() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		RequestDispatcher rd=request.getRequestDispatcher("DisplayDetails.jsp");
		rd.forward(request, response);
		/*PrintWriter out=response.getWriter();
		List<DetailsDaoBean> ls=new ArrayList<DetailsDaoBean>();
		Cookie ck[]=request.getCookies();
		int k=0;
		 if(ck!=null){ 
		for(int i=0;i<ck.length;i++)
		{
		//out.println(ck[i].getName()+""+ck[i].getValue()+""+i);
		
        
         String name=ck[i].getName();  
        // out.println(name);
        if(name.equals("username")){
        	k=1;
        }
        }
        }
		if(k==1)
		{//  TrainandDriverDetailApp tda=new TrainandDriverDetailApp();
            DetailsDao dd=new DetailsDao();
            ls=dd.display();
            out.println("<html><head><style>table, th, td {border: 1px solid black;}</style></head><center><body><table><tr><th>TrainId</th><th>TrainName</th><th>TrackId</th><th>DriverId</th><th>DriverName</th><th>DriverPhoneNumber</th><th>Status</th><th>Arrival</th><th>Departure</th><th>Date</th></tr>");
            for(DetailsDaoBean ddb:ls)
            {
            	out.println("<tr>");
    			out.println("<td>"); out.println(ddb.getTrainid()); 	out.println("</td>");
    			out.println("<td>");out.println(ddb.getTrainname());  	out.println("</td>");
    			out.println("<td>");out.println(ddb.getTrackid());	out.println("</td>");
    			out.println("<td>");out.println(ddb.getDriverid());	out.println("</td>");
    			out.println("<td>");out.println(ddb.getDrivername());	out.println("</td>");
    			out.println("<td>");out.println(ddb.getDriverphoneno());	out.println("</td>");
    			out.println("<td>");out.println(ddb.getStatus());	out.println("</td>");
    			out.println("<td>");out.println(ddb.getArrival());	out.println("</td>");
    			out.println("<td>");out.println(ddb.getDeparture());	out.println("</td>");
    			out.println("<td>");out.println(ddb.getTdate());	out.println("</td>");
    			out.println("</tr>");
            }
            
          
        }else{  
        	 out.print("<html><body><font size='5' color='blue'>Please login first</font></body></html>");  
             request.getRequestDispatcher("admin.html").include(request, response);  
        }  */
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
