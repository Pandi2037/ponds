package jsonprogram;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

import org.apache.log4j.Logger;

import CIT.Withoutcon;

public class Conn {
	final static Logger logger1 = Logger.getLogger(Conn.class);
	public Connection Connec()
	{
	 Connection con=null;
//	  Statement st=null;
	  try
	  {
		 
	  Class.forName("org.apache.derby.jdbc.ClientDriver");
	    
	   
	    //create connection object
	    
	  con=DriverManager.getConnection("jdbc:derby://172.24.21.41:1527/mydb","tuser","123");
	//  st=con.createStatement();
	  
	  }
	  catch(Exception e)
	  {
		  logger1.error("Database Error");
	  }
	  return con;
	}

}
