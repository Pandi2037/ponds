package jsonprogram;

import java.util.*;
import java.text.*;
public class TrainBean {
int trainid,trackid,driverid,phoneno;
String trainname,statusoftrain,arrival,departure,drivername;
String tdate;
DateFormat df=new SimpleDateFormat("yyyy-MM-dd");
public int getTrainid() {
	return trainid;
}
public void setTrainid(int trainid) {
	this.trainid = trainid;
}
public TrainBean(int trainid, int trackid, int driverid, String trainname,
		String statusoftrain, String arrival, String departure, String tdate,String drivername,int phoneno) {
	
	this.trainid = trainid;
	this.trackid = trackid;
	this.driverid = driverid;
	this.trainname = trainname;
	this.statusoftrain = statusoftrain;
	this.arrival = arrival;
	this.departure = departure;
	try {
		this.tdate=	df.format(df.parse(tdate));
	} catch (ParseException e) {
		// TODO Auto-generated catch block
		//System.out.println("cannot convert"+e);
		
	}
	this.drivername=drivername;
	this.phoneno=phoneno;
	
		 
	
}
public int getPhoneno() {
	return phoneno;
}
public void setPhoneno(int phoneno) {
	this.phoneno = phoneno;
}
public String getDrivername() {
	return drivername;
}
public void setDrivername(String drivername) {
	this.drivername = drivername;
}
public int getTrackid() {
	return trackid;
}
public void setTrackid(int trackid) {
	this.trackid = trackid;
}
public int getDriverid() {
	return driverid;
}
public void setDriverid(int driverid) {
	this.driverid = driverid;
}
public String getTrainname() {
	return trainname;
}
public void setTrainname(String trainname) {
	this.trainname = trainname;
}
public String getStatusoftrain() {
	return statusoftrain;
}
public void setStatusoftrain(String statusoftrain) {
	this.statusoftrain = statusoftrain;
}
public String getArrival() {
	return arrival;
}
public void setArrival(String arrival) {
	this.arrival = arrival;
}
public String getDeparture() {
	return departure;
}
public void setDeparture(String departure) {
	this.departure = departure;
}
public String getTdate() {
	return tdate;
}
public void setTdate(String tdate) {
	this.tdate = tdate;
}
}
