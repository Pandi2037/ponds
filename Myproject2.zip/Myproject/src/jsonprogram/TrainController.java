package jsonprogram;


import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;



@RestController
@RequestMapping(value = "/all")
public class TrainController {
	@RequestMapping(value = "/train", method = RequestMethod.GET)
	public List<TrainBean> getAllStocks() throws SQLException {

		Conn c1 = new Conn();
		Connection con = c1.Connec();
		Statement st = con.createStatement();
		ArrayList list = new ArrayList<TrainBean>();
		String s = "select * from T_XBBNHCF_CIT1";
		String s1 = "select * from T_XBBNHCF_CIT2";
		ResultSet rs = st.executeQuery(s);
		Statement st1 = con.createStatement();
		ResultSet rs1 = st1.executeQuery(s1);
		while (rs.next()&&rs1.next()) {
			list.add(new TrainBean(rs.getInt("trainid"),rs.getInt("trackid"),rs.getInt("driverid"),rs.getString("trainname"),rs.getString("statusoftrain"),rs.getString("arrival"),rs.getString("departure"),rs.getString("tdate"),rs1.getString("drivername"),rs1.getInt("driverphone")));
		}
		return list;
	}
	

}
